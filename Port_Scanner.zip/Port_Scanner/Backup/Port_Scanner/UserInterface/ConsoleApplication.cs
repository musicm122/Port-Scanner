﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Port_Scanner
{
    public class ConsoleApplication
    {
        /*
        public void Menu() 
        {
            while(true) 
            {
                //Call Menu
                Console.WriteLine("Port Scanner 2.0 by Terrance Smith");
                CallHelp();
                
                //wait for input
                //switch for action
            }
        }
        
        public static void CallHelp() 
        {
            Console.WriteLine("Port Scanner 2.0 by Terrance Smith");
            Console.WriteLine("Scan given IP address from start port to end port");
            Console.WriteLine("syntax: [ip address] [start port] [end port]");
            
            Console.WriteLine("Scan localhost address from start port to end port");
            Console.WriteLine("syntax:\r\n [ip address] [start port] [end port] ");
            
            Console.WriteLine("Scan localhost address from start port to end port");
            Console.WriteLine("syntax:\r\n [ip address] [start port] [end port] ");
        }
        
        public static void ErrorMessage(string message) 
        {
            Console.WriteLine(message);
        }
    }
}
